<%@page import="java.util.Enumeration"%>
<%@page import="com.oreilly.servlet.MultipartRequest"%>
<%@page import="com.oreilly.servlet.multipart.DefaultFileRenamePolicy"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<html>
<head>
<meta charset="UTF-8">
<title>update product</title>
</head>
<body>
<%@ include file="dbconn.jsp" %>
	<%
	
		request.setCharacterEncoding("UTF-8");
		
		String filename="";
		//String realFolder="C:/Users/Administrator/eclipse-workspace/kang/src/main/webapp/assets/img/upload"; //이미지가 저장되는 경로
		String realFolder=application.getRealPath("/assets/img/upload/"); //이미지가 저장되는 경로
		String encType="utf-8";
		int maxSize = 5*1024*1024;
		MultipartRequest multi = new MultipartRequest(request, realFolder, maxSize, encType, new DefaultFileRenamePolicy());
		
		String productId = multi.getParameter("productId");
		String productName = multi.getParameter("productName");
		String unitPrice = multi.getParameter("unitPrice");
		String description = multi.getParameter("description");
		String category = multi.getParameter("category");
		String manufacturer = multi.getParameter("manufacturer");
		String unitsInStock = multi.getParameter("unitsInStock");
		String condition = multi.getParameter("condition");
		
		
		int price;
		if(unitPrice.isEmpty()) price = 0;
		else price = Integer.valueOf(unitPrice);
		
		long stock;
		if(unitsInStock.isEmpty()) stock = 0;
		else stock =Long.valueOf(unitsInStock);
		
		Enumeration files = multi.getFileNames();
		String fname = (String)files.nextElement();
		String fileName = multi.getFilesystemName(fname);
		
			String sql = "select * from kangs_product where p_id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, productId);
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				if(fileName != null){
					sql="update kangs_product set p_name=?, p_unitPrice=?, p_description=?, p_category=?, p_manufacturer=?, p_unitsInStock=?, p_condition=?, p_fileName=?, p_quantity=10 where p_id=?";	
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, productName);
					pstmt.setInt(2, price);
					pstmt.setString(3, description);
					pstmt.setString(4, category);
					pstmt.setString(5, manufacturer);
					pstmt.setLong(6, stock);
					pstmt.setString(7, condition);
					pstmt.setString(8, fileName);
					pstmt.setString(9, productId);
					pstmt.executeUpdate();

				}else{
					sql="update kangs_product set p_name=?, p_unitPrice=?, p_description=?, p_category=?, p_manufacturer=?, p_unitsInStock=?, p_condition=?, p_fileName=?, p_quantity=10 where p_id=?";	
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, productName);
					pstmt.setInt(2, price);
					pstmt.setString(3, description);
					pstmt.setString(4, category);
					pstmt.setString(5, manufacturer);
					pstmt.setLong(6, stock);
					pstmt.setString(7, condition);
					pstmt.setString(8, productId);
					pstmt.executeUpdate();
				}
				
			}

			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			if (conn != null) conn.close();
		

		response.sendRedirect("editProduct.jsp?edit=update");
	%>
</body>
</html>
