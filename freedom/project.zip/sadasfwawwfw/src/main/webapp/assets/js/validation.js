
function checkUpdateProducts(){
	/*
		[1]상품 아이디: 첫글자를 p로 시작하고 숫자를 조합해서 5-6자리 입력
		[2]상품명: 최소 2자에서 최대 20자까지 입력
	*/	

	var name = document.getElementById("productName");
	var unitPrice = document.getElementById("unitprice");
	var unitsInStock = document.getElementById("unitsInStock");
	var img = document.getElementById("img");
	var productId = document.getElementById("productId");
	
	function check(regExp, e, msg){
		if(regExp.test(e.value)){
			return true;
		} else{
			alert(msg);
			e.select();
			e.focus();
			return false;
		}
	}
	
	if(!check(/^C[0-9]{4,5}$/, productId, "[상품 아이디]\n첫글자를 C로 시작하고 숫자를 조합해서 5-6자리 입력 가능합니다.")){
		productId.focus();
		productId.select();
		return false;
	}
	
	if(name.value.length <2 || name.value.length > 20){
		alert("[상품명]\n최소 2자에서 20자까지만 입력 가능합니다.")
		name.focus();
		name.select();
		return false;
	}
	if(unitPrice.value.length == 0 || isNaN(unitPrice.value)){
		alert("[상품가격]\n0숫자만 입력 가능합니다.")
			unitPrice.focus();
			unitPrice.select();
			return false;
	}

	if(unitPrice.value<= 0 ){
		alert("[상품가격]\n0이나 음수를 입력할 수 없습니다.")
		unitPrice.focus();
		unitPrice.select();
		return false;
	}else if(!check(/^\d+(?:[.]?[\d]{0}?)$/, unitPrice, "[상품 가격]\n소수점 자리수는 입력 안됩니다.")){
		return false;
	}
	
	if(unitsInStock.value.length == 0 || isNaN(unitsInStock.value)){
			alert("[재고수]\n숫자만 입력 가능합니다.")
				unitsInStock.focus();
				unitsInStock.select();
				return false;
		}

	if(unitsInStock.value < 0){
			alert("[재고수]\n음수를 입력할 수 없습니다.")
				unitsInStock.focus();
				unitsInStock.select();
				return false;
		}
		
	if(!(img.value)){
		alert("제품의 이미지를 첨부해 주세요.")
		return false;
	}
	document.checkUpdateProduct.submit();
}


function checkAddProducts(){
	/*
		[1]상품 아이디: 첫글자를 p로 시작하고 숫자를 조합해서 5-6자리 입력
		[2]상품명: 최소 2자에서 최대 20자까지 입력
	*/	

	var name = document.getElementById("productName");
	var unitPrice = document.getElementById("unitprice");
	var unitsInStock = document.getElementById("unitsInStock");
	var img = document.getElementById("img");
	var productId = document.getElementById("productId");
	
	function check(regExp, e, msg){
		if(regExp.test(e.value)){
			return true;
		} else{
			alert(msg);
			e.select();
			e.focus();
			return false;
		}
	}
	
	if(!check(/^C[0-9]{4,5}$/, productId, "[상품 아이디]\n첫글자를 C로 시작하고 숫자를 조합해서 5-6자리 입력 가능합니다.")){
		productId.focus();
		productId.select();
		return false;
	}
	
	if(name.value.length <2 || name.value.length > 20){
		alert("[상품명]\n최소 2자에서 20자까지만 입력 가능합니다.")
		name.focus();
		name.select();
		return false;
	}
	if(unitPrice.value.length == 0 || isNaN(unitPrice.value)){
		alert("[상품가격]\n0숫자만 입력 가능합니다.")
			unitPrice.focus();
			unitPrice.select();
			return false;
	}

	if(unitPrice.value<= 0 ){
		alert("[상품가격]\n0이나 음수를 입력할 수 없습니다.")
		unitPrice.focus();
		unitPrice.select();
		return false;
	}else if(!check(/^\d+(?:[.]?[\d]{0}?)$/, unitPrice, "[상품 가격]\n소수점 자리수는 입력 안됩니다.")){
		return false;
	}
	
	if(unitsInStock.value.length == 0 || isNaN(unitsInStock.value)){
			alert("[재고수]\n숫자만 입력 가능합니다.")
				unitsInStock.focus();
				unitsInStock.select();
				return false;
		}

	if(unitsInStock.value < 0){
			alert("[재고수]\n음수를 입력할 수 없습니다.")
				unitsInStock.focus();
				unitsInStock.select();
				return false;
		}
		
	if(!(img.value)){
		alert("제품의 이미지를 첨부해 주세요.")
		return false;
	}
	document.newProduct.submit();
}

