create table kangs_board(
    num number primary key,--게시글 순번은 시퀀스로 만들예정
    id varchar2(20) not null,--회원 아이디
    name varchar2(20) not null, --회원 이름
    subject varchar2(100) not null, --게시글 제목
    content varchar2(1000) not null, --게시글 내용
    hit number,--게시글 조회 수
    ip varchar2(20),--게시글 등록 ip
    regist_day  date default sysdate,
    update_day date default sysdate
);


--시퀀스 생성
create sequence num nocycle nocache;
-- 시퀀스 삭제
drop sequence num;


--데이터 저장 : paging 만들것이므로 데이터 26개 추가할 것!
insert into board values  (num.nextval,'pretty', '정민우', '배송 언제 오나요?', '주문한지 일주일이 지났는데 아직 배송이 안되었어요.ㅠㅠ', 1, '128.120.0.02', sysdate, sysdate); --seq_num.currval


--데이터 검색기능
SELECT  count(*) FROM board where content like '%테스%';
SELECT  count(*) FROM board where subject like '%게시%';
SELECT  count(*) FROM board where name like '%관리자%';



--데이터 수정
update board set subject='수정', update_day=sysdate where num='3';


--데이터 읽기
select * from board;
select count(*) from board;
select count(*) from board where name like '%김%';
select * from board ORDER BY num DESC;
select * from board ORDER BY board_seq DESC;
SELECT  * FROM board where name like '%큐%' ORDER BY board_seq DESC;
desc board;


--조건에 맞는 데이터 삭제
delete board where id='cuty';


--테이블 삭제
drop table board;
select * from board;
rollback;
commit;