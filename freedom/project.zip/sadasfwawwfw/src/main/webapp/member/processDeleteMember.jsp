<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="sql" uri="http://java.sun.com/jsp/jstl/sql" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
request.setCharacterEncoding("UTF-8");

String id = request.getParameter("id");

 %>
<sql:setDataSource var="dataSource" url="jdbc:oracle:thin:@localhost:1521:xe" driver="oracle.jdbc.driver.OracleDriver" user="C##dbexam" password="m1234"/>

<sql:query dataSource="${dataSource } var="resultSet">
 kangs_member values('?','?','?','?','?','?','?','?',' ?',seq_num.nextval, sysdate, sysdate)
<sql:param value="<%=id %>"/>
</sql:query>

<c:if test="${resultSet=1 }">
	<c:redirect url="resultMember.jsp?msg=1"></c:redirect>
</c:if>
</body>
</html>
</body>
</html>