<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ taglib prefix="sql" uri="http://java.sun.com/jsp/jstl/sql" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
    
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta
      name="author"
      content="Mark Otto, Jacob Thornton, and Bootstrap contributors"
    />
    <meta name="generator" content="Astro v5.13.2" />
    <title>Checkout example · Bootstrap v5.3</title>
    <link
      rel="canonical"
      href="https://getbootstrap.com/docs/5.3/examples/checkout/"
    />
    <script src="../assets/js/color-modes.js"></script>
    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet" />
    <meta name="theme-color" content="#712cf9" />
    <link href="checkout.css" rel="stylesheet" />
    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }
      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: #0000001a;
        border: solid rgba(0, 0, 0, 0.15);
        border-width: 1px 0;
        box-shadow:
          inset 0 0.5em 1.5em #0000001a,
          inset 0 0.125em 0.5em #00000026;
      }
      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }
      .bi {
        vertical-align: -0.125em;
        fill: currentColor;
      }
      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }
      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }
      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;
        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }
      .bd-mode-toggle {
        z-index: 1500;
      }
      .bd-mode-toggle .bi {
        width: 1em;
        height: 1em;
      }
      .bd-mode-toggle .dropdown-menu .active .bi {
        display: block !important;
      }
    </style>
	<script>
		function checkForm(){
		if(!document.newMember.id.value){
		alert("아이디를 입력해주세요.")
		return false;
		}
		if(!document.newMember.pw.value){
		alert("비번을 입력해주세요.")
		return false;
		}
		if(!document.newMember.pw_confirm.value){
		alert("비번확인을 입력해주세요.")
		return false;
		}
		if(document.newMember.pw.value != document.newMember.pw_confirm.value){
		alert("비번을 동일하게 입력해주세요.")
		return false;
		}
		if(!document.newMember.name.value){
		alert("이름을 입력해주세요.")
		return false;
		}
		document.newMember.submit();
		}
	</script>
  </head>
<body>
	<%@ include file="../menu.jsp" %>
	<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
					<li class="nav-item text-success"><a>회원 수정</a></li>
				</ul>
			</div>
		</div>
	</div>
	
		<c:forEach var="row" items="${resultSet.rows }">
		<c:set value="${row.mail }" var="mail"/>
		<c:set value="${mail.split('@')[0] }" var="mail1"/>
		<c:set value="${mail.split('@')[1] }" var="mail2"/>

		<c:set value="${row.birth }" var="birth"/>
		<c:set value="${birth.split('-')[0] }" var="year"/>
		<c:set value="${birth.split('-')[1] }" var="month"/>
		<c:set value="${birth.split('-')[2] }" var="day"/>
    <div class="container">
      <main>
          <div class="col-md-7 col-lg-8">
            <h4 class="mb-3">회원 정보를 기입하세요.</h4>
            <form class="needs-validation" novalidate>
              <div class="row g-3">
                <div class="col-12">
                  <label for="firstName" class="form-label">아이디</label>
                  <input
                    type="text"
                    class="form-control"
                    id="firstName"
                    placeholder=""
                    value='<c:out value="${row_id }"/>'>
                    required
                  />
                  <div class="invalid-feedback">
                    Valid first name is required.
                  </div>
                </div>
                <div class="col-12">
                  <label for="password" class="form-label">비밀번호</label>
                  <div class="input-group has-validation">
                    <input
                      type="text"
                      class="form-control"
                      id="password"
                      placeholder=""
                      required
                    />
                    <div class="invalid-feedback">
                      Your password is required.
                    </div>
                  </div>
                </div>
                  <label for="password" class="form-label">비밀번호 확인</label>
                  <div class="input-group has-validation">
                    <input
                      type="text"
                      class="form-control"
                      id="pw_confirm"
                      placeholder=""
                      required
                    />
                    <div class="invalid-feedback">
                      Your password is required.
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <label for="email" class="form-label">닉네임</label>
                  <input
                    type="text"
                    class="form-control"
                    id="nickname"
                    placeholder=""
                  />
                  <div class="invalid-feedback">
                    Please enter a nickname.
                  </div>
                </div>
				<div class="form-group my-4">
				<label for="gender">성별</label>
				<c:set var="gender" value="${row.gender }"/>
				  <input class="form-check-input" type="radio" name="gender" id="flexRadioDefault1">
				  <label class="form-check-label" for="gender1">
				    Default radio
				  </label>
				</div>
				<div class="form-check">
				  <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
				  <label class="form-check-label" for="flexRadioDefault2">
				    Default checked radio
				  </label>
				</div>
                </div>
                <div class="col-12">
                  <label for="birth" class="form-label"
                    >생년월일</label>
					<select class="box form-control" id="birth-year" name="birthyy">
					  <option selected>${year}</option>					  
					</select>
					<select class="box form-control" id="birth-month" name="birthmm">
					  <option selected>${year}</option>					  
					</select>
					<select class="box form-control" id="birth-day" name="birthdd">
					  <option selected>${year}</option>					  
					</select>
				</div>
                <div class="col-12">
                  <label for="mail" class="form-label"
                    >이메일</label>
					<select class="box form-control" id="birth-year" name="birthyy">
					<c:if>
					  <option selected>${year}</option>					  
					</select>
					<select class="box form-control" id="birth-month" name="birthmm">
					  <option selected>${year}</option>					  
					</select>
					<select class="box form-control" id="birth-day" name="birthdd">
					  <option selected>${year}</option>					  
					</select>
					</c:if> 
				</div>
                <div class="col-md-3">
                  <label for="zip" class="form-label">Zip</label>
                  <input
                    type="text"
                    class="form-control"
                    id="zip"
                    placeholder=""
                    required
                  />
                  <div class="invalid-feedback">Zip code required.</div>
                </div>
              </div>
              <hr class="my-4" />
              <div class="form-check">
                <input
                  type="checkbox"
                  class="form-check-input"
                  id="same-address"
                />
                <label class="form-check-label" for="same-address"
                  >Shipping address is the same as my billing address</label
                >
              </div>
              <div class="form-check">
                <input
                  type="checkbox"
                  class="form-check-input"
                  id="save-info"
                />
                <label class="form-check-label" for="save-info"
                  >Save this information for next time</label
                >
              </div>
              <hr class="my-4" />
              <h4 class="mb-3">Payment</h4>
              <div class="my-3">
                <div class="form-check">
                  <input
                    id="credit"
                    name="paymentMethod"
                    type="radio"
                    class="form-check-input"
                    checked
                    required
                  />
                  <label class="form-check-label" for="credit"
                    >Credit card</label
                  >
                </div>
                <div class="form-check">
                  <input
                    id="debit"
                    name="paymentMethod"
                    type="radio"
                    class="form-check-input"
                    required
                  />
                  <label class="form-check-label" for="debit">Debit card</label>
                </div>
                <div class="form-check">
                  <input
                    id="paypal"
                    name="paymentMethod"
                    type="radio"
                    class="form-check-input"
                    required
                  />
                  <label class="form-check-label" for="paypal">PayPal</label>
                </div>
              </div>
              <div class="row gy-3">
                <div class="col-md-6">
                  <label for="cc-name" class="form-label">Name on card</label>
                  <input
                    type="text"
                    class="form-control"
                    id="cc-name"
                    placeholder=""
                    required
                  />
                  <small class="text-body-secondary"
                    >Full name as displayed on card</small
                  >
                  <div class="invalid-feedback">Name on card is required</div>
                </div>
                <div class="col-md-6">
                  <label for="cc-number" class="form-label"
                    >Credit card number</label
                  >
                  <input
                    type="text"
                    class="form-control"
                    id="cc-number"
                    placeholder=""
                    required
                  />
                  <div class="invalid-feedback">
                    Credit card number is required
                  </div>
                </div>
                <div class="col-md-3">
                  <label for="cc-expiration" class="form-label"
                    >Expiration</label
                  >
                  <input
                    type="text"
                    class="form-control"
                    id="cc-expiration"
                    placeholder=""
                    required
                  />
                  <div class="invalid-feedback">Expiration date required</div>
                </div>
                <div class="col-md-3">
                  <label for="cc-cvv" class="form-label">CVV</label>
                  <input
                    type="text"
                    class="form-control"
                    id="cc-cvv"
                    placeholder=""
                    required
                  />
                  <div class="invalid-feedback">Security code required</div>
                </div>
              </div>
              <hr class="my-4" />
              <button class="w-100 btn btn-primary btn-lg" type="submit">
                Continue to checkout
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>

	<div class="form-group my-4">
		<input type="button" class="btn btn-primary" value="수정" onclick="checkForm()">
		<a href="deleteMember.jsp" class="btn btn-danger">탈퇴</a>
	</div>

    <%@ include file="../footer.jsp" %>
    <script
      src="../assets/dist/js/bootstrap.bundle.min.js"
      class="astro-vvvwv3sm"
    ></script>
    <script src="../checkout.js" class="astro-vvvwv3sm"></script>
    	</c:forEach>
 
</body>
</html>