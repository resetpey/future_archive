<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="sql" uri="http://java.sun.com/jsp/jstl/sql" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
request.setCharacterEncoding("UTF-8");

String id = request.getParameter("id");
String password = request.getParameter("password");
String name = request.getParameter("name");
String gender = request.getParameter("gender");//String month = request.getParameterValues("birthmm")[0];
String year = request.getParameter("birthyy");
String month = request.getParameter("birthmm");
String day = request.getParameter("birthdd");
String birth = year+"-"+month+"-"+day;
String mail1 = request.getParameter("mail1");
String mail2 = request.getParameter("mail2");//String mail2 = request.getParameterValues("mail2")[0];
String mail = mail1 + "@" +mail2;
String phone = request.getParameter("phone");
String address = request.getParameter("address");
 %>
<sql:setDataSource var="dataSource" url="jdbc:oracle:thin:@localhost:1521:xe" driver="oracle.jdbc.driver.OracleDriver" user="C##dbexam" password="m1234"/>

<sql:update dataSource="${dataSource } var="resultSet">
insert into kangs_member values(?,?,?,?,?,?,?,?,?,kangs_seq_num.nextval, sysdate, sysdate)
<sql:param value="<%=id %>"/>
<sql:param value="<%=password %>"/>
<sql:param value="<%=name %>"/>
<sql:param value="<%=gender %>"/>
<sql:param value="<%=birth %>"/>
<sql:param value="<%=mail %>"/>
<sql:param value="<%=phone %>"/>
<sql:param value="<%=address %>"/>
</sql:update>

<c:if test="${resultSet=1 }">
	<c:redirect url="resultMember.jsp?msg=1"></c:redirect>
</c:if>
</body>
</html>