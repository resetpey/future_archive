<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%@ include file="../menu.jsp" %>
		<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
			 		<li class="nav-item text-dark">
			 	    	 <b>상품목록</b>
			  		</li>
				</ul>
			</div>
		</div>
	</div>
	
	<div class="container">
		<%
			String msg = request.getParameter("msg");
		if(msg !=null){
			if(msg.equals("0")) out.print("<h2>회원정보가 수정되었습니다.</h2>");
			else if(msg.equals("1")) out.print("회원가입되었습니다. 감사합니다. 다시 로그인 해주세요.");
			else if(msg.equals("2")){
				String loginId = (String)session.getAttribute("sessionId");
				out.print(loginId+"님 환영합니다.");
			}
			else if(msg.equals("3")){
				out.print("탈퇴가 완료되었습니다.");
			}
		}else{
			out.print("회원정보가 존재하지 않습니다.");
		}
		%>
	</div>
    <%@ include file="../footer.jsp" %>
</body>
</html>