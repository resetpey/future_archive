<%@ page language="java" contentType="text/html; charset=UTF-8"
pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style>
.bd-placeholder-img {
font-size: 1.125rem;
text-anchor: middle;
-webkit-user-select: none;
-moz-user-select: none;
user-select: none;
}


@media ( min-width : 768px) {
.bd-placeholder-img-lg {
font-size: 3.5rem;
}
}
</style>


</head>
<body>
<%@ include file="../menu.jsp"%>
<div class="container-fluid">
<div class="row">
<div class="col bg-light">
<ul class="nav justify-content-center p-5">
<li class="nav-item text-success"><b>회원가입</b></li>
</ul>
</div>
</div>
</div>
<div class="container">
<!-- 9-7)action="processAddMember.jsp" 을 주고 버튼에 checkForm()호출하거나 form에 onsubmit="return checkForm()"을 주어도 됨!-->
<!-- bs4 form -->
<form name="newMember" action='<c:url value="/member/processAddMember.jsp" />'>
<div class="form-group my-4">
<label for="id">아이디</label>
<input type="text" class="form-control" id="id" name="id" placeholder="아이디" required autofocus>
</div>
<div class="form-group my-4">
<label for="pw">비밀번호</label>
<input type="password" class="form-control" id="pw" name="pw" required>
</div>
<div class="form-group my-4">
<label for="pw_confirm">비밀번호 확인</label>
<input type="password" class="form-control" id="pw_confirm" name="pw_confirm" required>
</div>
<div class="form-group">
<label for="name">이름</label>
<input type="text" class="form-control" id="name" name="name" placeholder="이름" required>
</div>
<div class="form-group my-4">
<label for="gender">성별</label>
<div class="form-check">
<input class="form-check-input" type="radio" name="gender" id="gender1" value="남" checked>
<label class="form-check-label" for="gender1">
남성
</label>
</div>
<div class="form-check">
<input class="form-check-input" type="radio" name="gender" id="gender2" value="여">
<label class="form-check-label" for="gender2">
여성
</label>
</div>
</div>
<div class="form-group my-4">
<label>생년월일</label>
<div class="info" id="info__birth">
<!-- <input type="number" min="1900" max="2023" value="1980" class="form-control" placeholder="ID" name='id'> -->
<select class="box form-control" id="birth-year" name="birthyy">
<option disabled selected>출생 연도</option>
</select>
<select class="box form-control" id="birth-month" name="birthmm">
<option disabled selected>월</option>
</select>
<select class="box form-control" id="birth-day" name="birthdd">
<option disabled selected>일</option>
</select>
</div>
</div>
<div class="form-group my-4">
<label for="email">이메일</label><br />
<input type="text" class="form-control d-inline w-50" id="mail1" name="mail1" placeholder="이메일" required autofocus>@
<select name="mail2" id="mail2" class="form-control d-inline w-25">
<option>ncaver.com</option>
<option>gmail.com</option>
<option>nate.com</option>
<option>daum.com</option>
</select>
</div>
<div class="form-group my-4">
<label for="phone">연락처</label>
<input type="text" class="form-control" id="phone" name="phone" placeholder="연락처" required autofocus>
</div>
<div class="form-group my-4">
<label for="address">주소</label>
<input type="text" class="form-control" id="address" name="address" placeholder="주소" required autofocus>
</div>
<div class="form-group my-4">
<input type="button" class="btn btn-primary" value="등록" onclick="checkForm()">
<input type="reset" class="btn btn-danger" value="취소">
</div>
</form>
<div class="my-4"></div>
</div>
<%@ include file="../footer.jsp"%>
<script>
//'출생 연도' 셀렉트 박스 option 목록 동적 생성
const birthYearEl = document.querySelector('#birth-year')
// option 목록 생성 여부 확인
isYearOptionExisted = false;
birthYearEl.addEventListener('focus', function () {
// year 목록 생성되지 않았을 때 (최초 클릭 시)
if(!isYearOptionExisted) {
isYearOptionExisted = true
for(var i = 1940; i <= 2024; i++) {
// option element 생성
const YearOption = document.createElement('option')
YearOption.setAttribute('value', i)
YearOption.innerText = i
// birthYearEl의 자식 요소로 추가
this.appendChild(YearOption);
}
}
});
// Month
const birthMonthEl = document.querySelector('#birth-month')
// option 목록 생성 여부 확인
isMonthOptionExisted = false;
birthMonthEl.addEventListener('focus', function () {
// year 목록 생성되지 않았을 때 (최초 클릭 시)
if(!isMonthOptionExisted) {
isMonthOptionExisted = true
for(var i = 1; i <= 12; i++) {
// option element 생성
const MonthOption = document.createElement('option')
if(i<10){
MonthOption.setAttribute('value', "0"+i)
MonthOption.innerText = "0"+i
}else{
MonthOption.setAttribute('value', i)
MonthOption.innerText = i
}
// birthYearEl의 자식 요소로 추가
this.appendChild(MonthOption);
}
}
});
//Day도 동일한 방식으로 구현
const birthDayEl = document.querySelector('#birth-day')
// option 목록 생성 여부 확인
isDayOptionExisted = false;
birthDayEl.addEventListener('focus', function () {
// year 목록 생성되지 않았을 때 (최초 클릭 시)
if(!isDayOptionExisted) {
isDayOptionExisted = true
for(var i = 1; i <= 31; i++) {
// option element 생성
const DayOption = document.createElement('option')
if(i<10){
DayOption.setAttribute('value', "0"+i)
DayOption.innerText = "0"+i
}else{
DayOption.setAttribute('value', i)
DayOption.innerText = i
}
// birthYearEl의 자식 요소로 추가
this.appendChild(DayOption);
}
}
});
</script>
</body>
</html>