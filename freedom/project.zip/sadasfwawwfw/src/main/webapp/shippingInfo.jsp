<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%@ include file="menu.jsp" %>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
					<li class="nav-item text-success"><b>배송 정보</b></li>
				</ul>
			</div>
		</div>
		<div class="row">
			<div class="col p-5">
				<%
					String cartId = session.getId();
				%>
				<form action="processShippingInfo.jsp?cartId=<%=cartId %>" method="post">
				<input type="hidden" value="<%=cartId %>" name="cartId"/>
					<div class="mb-3">
						<label for="exampleFormControlInput1" class="form-label">성명</label> <input type="text" class="form-control"
							id="exampleFormControlInput1" name="name">
					</div>
					<div class="mb-3">
						<label for="exampleFormControlInput2" class="form-label">배송일</label> <input type="text" class="form-control"
							id="exampleFormControlInput2" placeholder="yyyy/mm/dd" name="date">
					</div>
					<div class="mb-3">
						<label for="exampleFormControlInput3" class="form-label">주소입력</label> <input type="text" class="form-control"
							id="exampleFormControlInput3" name="address">
					</div>
					<div class="mb-3">
						<label for="exampleFormControlInput4" class="form-label">우편번호 입력</label> <input type="text" class="form-control"
							id="exampleFormControlInput4" name="postId">
					</div>
					<div class="mb-3">
						<a href="./cart.jsp" class="btn btn-primary w-100 my-2">이전</a>
						<input type="submit" class="form-control btn btn-info"
							id="exampleFormControlInput4" value="등록">
						<a href="./checkOutCancelled.jsp" class="btn btn-warning w-100 my-2">취소</a>
					</div>
				</form>
			</div>
		</div>
	</div>	
	<%@ include file="footer.jsp" %>
</body>
</html>