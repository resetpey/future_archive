<%@page import="java.text.DecimalFormat"%>
<%@ page import="dto.Product" %>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>제품 상세 페이지</title>
</head>
<body>
	<%@ include file="dbconn.jsp" %>
	<%@ include file="menu.jsp" %>
			<div class="container-fluid">
				<div class="row">
					<div class="col bg-light">
						<ul class="nav justify-content-center p-5">
					 		<li class="nav-item">
					 	    	<b>상품정보</b>
					  		</li>
						</ul>
					</div>
				</div>
			</div>
		<%
			String id = request.getParameter("id");
			String sql = "select * from kangs_product where p_id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			DecimalFormat formatter = new DecimalFormat("#,###");
			if(rs.next()){
				String condition = rs.getString("p_condition");
				
		%>
			<div class="container p-5">
				<div class="row">
				<form action="./processUpdateProduct.jsp" name="updateProduct">
					<div class="col-md-6 p-5">
						<h3 class="mb-5"><%=rs.getString("p_name") %></h3>
										<img alt="" src="${pageContext.request.contextPath}/assets/img/upload/<%=rs.getString("p_fileName") %>" class="img-fluid">
						<p><%=rs.getString("p_description") %></p>
						<p><b>상품 코드 </b><%=rs.getString("p_id") %></p>
						<input type="text" class="form-control" id="productId" name="productId" value="<%=rs.getString("p_id")%>">
						<p><b>제조사 </b><%=rs.getString("p_manufacturer") %></p>
						<input type="text" class="form-control" id="manufacturer" name="manufacturer" value="<%=rs.getString("p_manufacturer")%>">
						<p><b>분류 </b><%=rs.getString("p_category") %></p>
						<input type="text" class="form-control" id="category" name="category" value="<%=rs.getString("p_category")%>">
						
						<p><b>재고 수 </b><%=formatter.format(rs.getLong("p_unitsInStock")) %>개</p>
						<input type="text" value="<%=rs.getLong("p_unitsInStock")%>">
						<p><b>상품 가격 </b><%=formatter.format(rs.getInt("p_unitPrice")) %>원</p>
						<input type="text" value="<%=rs.getInt("p_unitsInStock")%>">
						<p><b class="cs-bold cs-small">상품 상태 </b>
						<%=rs.getString("p_condition") %>
						<input type="radio" <%="new".equals(condition) ? "checked" : "" %> value="new">신규제품 &nbsp;
						<input type="radio" <%="old".equals(condition) ? "checked" : "" %> value="new">중고제품 &nbsp;
						<input type="radio" <%="recycling".equals(condition) ? "checked" : "" %> value="new">재생제품 &nbsp;
						</p>

			
						<button type="submit" onclick="checkEditProduct()" class="btn btn-dark">수정하기</button>
					</div>
					</form>
					</div>
  						
					</div>
			<%
				}
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
			%>
    <%@ include file="footer.jsp" %>
</body>
</html>