<%@page import="dto.Product"%>
<%@page import="java.util.ArrayList"%>
<%@page import="java.net.URLDecoder"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>orderConfirm</title>
</head>

<body>

	<%
	request.setCharacterEncoding("utf-8");

	String Shipping_cartId = "";
	String Shipping_name = "";
	String Shipping_date = "";
	String Shipping_address = "";
	String Shipping_postId = "";

	Cookie[] cookies = request.getCookies();

	if (cookies != null) {

		for (int i = 0; i < cookies.length; i++) {

			Cookie thisCookie = cookies[i];

			String n = thisCookie.getName();

			if (n.equals("Shipping_cartId"))
		Shipping_cartId = URLDecoder.decode(thisCookie.getValue(), "utf-8");

			if (n.equals("Shipping_name"))
		Shipping_name = URLDecoder.decode(thisCookie.getValue(), "utf-8");

			if (n.equals("Shipping_date"))
		Shipping_date = URLDecoder.decode(thisCookie.getValue(), "utf-8");

			if (n.equals("Shipping_address"))
		Shipping_address = URLDecoder.decode(thisCookie.getValue(), "utf-8");

			if (n.equals("Shipping_postId"))
		Shipping_postId = URLDecoder.decode(thisCookie.getValue(), "utf-8");
		}
	}
	%>

	<h1>
		<%=Shipping_cartId%>
		<%=Shipping_name%>
		<%=Shipping_date%>
		<%=Shipping_address%>
		<%=Shipping_postId%>
	</h1>
	<%@ include file="menu.jsp"%>
	<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
					<li class="nav-item text-success"><b>주문 정보</b></li>
				</ul>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col">
					<p class="text-center h3 my-5">영수증</p>
				</div>
			</div>
			<div class="row">
				<div class="col-4 text-left">
					<strong>배송 주소 : <br /> 성명 | <%=Shipping_name%></strong> <br />
					우편번호 |
					<%=Shipping_postId%></strong> <br /> 세부주소 |
					<%=Shipping_address%></strong>
				</div>
				<div class="col-4"></div>
				<div class="col-4 text-right">
					<strong>배송일 : <br /> 배송예정날짜 | <%=Shipping_date%></strong>
				</div>
			</div>
			<div class="row">
				<div class="col p-5">
					<table class="table table-striped m-5">
						<thead>
							<tr>
								<th scope="col">상품</th>
								<th scope="col">가격</th>
								<th scope="col">수량</th>
								<th scope="col">소계</th>
							</tr>
						</thead>
						<%
						int sum = 0;
						ArrayList<Product> cartlist = (ArrayList<Product>) session.getAttribute("cartlist");
						
						if (cartlist == null)
							cartlist = new ArrayList<Product>();
						for (int i = 0; i < cartlist.size(); i++) {
							Product product = cartlist.get(i);
							int total = product.getUnitPrice() * product.getQuantity();
							sum += total;
						%>
						<tr>
							<th scope="row"><%=product.getPname()%></th>
							<td><%=product.getUnitPrice()%></td>
							<td><%=product.getQuantity()%></td>
							<td><%=total%></td>
							<%
						}
						%>
						
						<tr>
							<th></th>
							<th></th>
							<th>총액</th>
							<th><%=sum%></th>
						</tr>
					</table>
					<a href="./products.jsp" class="btn btn-secondary">쇼핑 계속하기</a>
					<%
					String cartId = session.getId();
					%>

					<a href="./checkOutCancelled.jsp"
						class="btn btn-warning float-end mx-2">주문취소</a> 
					<a href="./thanksCustomer.jsp"
						class="btn btn-primary float-end mx-2">주문완료</a> <a
						href="./shippingInfo.jsp" class="btn btn-warning float-end">이전</a>
				</div>
			</div>
		</div>
	</div>
	<%@ include file="footer.jsp"%>

</body>
</html>

