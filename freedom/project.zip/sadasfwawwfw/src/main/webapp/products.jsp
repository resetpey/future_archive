
<%@page import="java.text.DecimalFormat"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<jsp:useBean id="productDAO" class="dao.ProductRepository" scope="session"/>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

	<%@ include file="menu.jsp" %>
	<%@ include file="dbconn.jsp" %>
	<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
			 		<li class="nav-item text-dark">
			 	    	 <b>상품목록</b>
			  		</li>
				</ul>
			</div>
		</div>
	</div>
	
	<div class="container pt-5">
		<div class="row">
		<%
			String sql = "select * from kangs_product";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
		%>
			<div class="col">
				<h3 class="mb-5"><%=rs.getString("p_name") %></h3>
				<img alt="" src="${pageContext.request.contextPath}/assets/img/upload/<%=rs.getString("p_fileName") %>" class="img-fluid">
				<p><%=rs.getString("p_description") %></p>
				<%
					DecimalFormat formatter = new DecimalFormat("#,###");
				%>
				<p><%=formatter.format(rs.getInt("p_unitPrice")) %>원</p>
				<p><a href="product.jsp?id=<%=rs.getString("p_id") %>" class="btn btn-outline-dark mt-3">상세 정보</a></p>
			</div>
			<%
				}
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
			%>
		</div>
	</div>
	<%@ include file="footer.jsp" %>

</body>
</html>