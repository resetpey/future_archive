<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<fmt:setLocale value='<%=request.getParameter("language") %>'/>
				<fmt:bundle basename="bundle.message">
	<%@ include file="menu.jsp" %>

			<div class="container-fluid">
				<div class="row">
					<div class="col bg-light">
						<ul class="nav justify-content-center p-5">
					 		<li class="nav-item">
					 	    	<b><fmt:message key="title"/></b>
					  		</li>
						</ul>
					</div>
				</div>
			</div>

			
			<div class="row">
				<div class="col">
					<form action="./processAddProduct.jsp" name="newProduct" method="post" enctype="multipart/form-data">
						<div class="mb-3 pe-5 pe-3">
							<label for="productId" class="form-Label"><fmt:message key="productId"/></label>
							<input type="text" class="form-control" id="productId" name="productId">
							<div class="form-text"><fmt:message key="ProductId"/></div> 
						</div>
						<div class="mb-3 pe-5 pe-3">
							<label for="productName" class="form-Label"><fmt:message key="productName"/></label>
							<input type="text" class="form-control" id="productName" name="productName">
							<div class="form-text"><fmt:message key="ProductName"/></div> 
						</div> 
						<div class="mb-3 pe-5 pe-3">
							<label for="unitPrice" class="form-Label"><fmt:message key="unitPrice"/></label>
							<input type="text" class="form-control" id="unitPrice" name="unitPrice">
							<div class="form-text"><fmt:message key="UnitPrice"/></div> 
						</div>
						<div class="mb-3 pe-5 pe-3">
							<label for="description" class="form-Label"><fmt:message key="description"/></label>
							<input type="text" class="form-control" id="description" name="description">
							<div class="form-text"><fmt:message key="Description"/></div> 
						</div>
						<div class="mb-3 pe-5 pe-3">
							<label for="Category" class="form-Label"><fmt:message key="Category"/></label>
							<input type="text" class="form-control" id="Category" name="Category">
							<div class="form-text"><fmt:message key="Category"/></div> 
						</div>
						<div class="mb-3 pe-5 pe-3">
							<label for="Manufacturer" class="form-Label"><fmt:message key="Manufacturer"/></label>
							<input type="text" class="form-control" id="Manufacturer" name="Manufacturer">
							<div class="form-text"><fmt:message key="Manufacturer"/></div> 
						</div>
						<div class="mb-3 pe-5 pe-3">
							<label for="unitsInStock" class="form-Label"><fmt:message key="unitsInStock"/></label>
							<input type="text" class="form-control" id="unitsInStock" name="unitsInStock">
							<div class="form-text"><fmt:message key="UnitsInStock"/></div> 
						</div>
						<div class="mb-3 pe-5 pe-3">
							<label for="condition" class="form-Label"><fmt:message key="condition"/></label>
							<div class="form-check">
								<input type="radio" class="form-check-input" id="condition1" name="condition" checked>
								<label class="form-check-label" for="condition1"> <fmt:message key="condition1"/> </label>
							</div>
							<div class="form-check">
								<input type="radio" class="form-check-input" id="condition2" name="condition">
								<label class="form-check-label" for="condition2"> <fmt:message key="condition2"/> </label>
							</div>
							<div class="form-check">
								<input type="radio" class="form-check-input" id="condition3" name="condition">
								<label class="form-check-label" for="condition3"> <fmt:message key="condition3"/> </label>
							</div>
						<div class="file">
							<div class="form-text"><fmt:message key="productimg"/></div>
							<input type="file" id="img" name="img"> 
						</div>
  							<button type="submit" onclick="checkAddProducts()" class="btn btn-dark"><fmt:message key="submit"/></button>
						</div>
					</form>
				</div>
			</div>
	</fmt:bundle>
	<%@ include file="footer.jsp" %>
	
</body>
</html>