<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@page import="java.util.ArrayList"%>
    <%@page import="dto.Product"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%@ include file="menu.jsp" %>
		<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">상품</th>
      <th scope="col">가격</th>
      <th scope="col">수량</th>
      <th scope="col">소계</th>
      <th scope="col">비고</th>
    </tr>
  </thead>
  <tbody class="table-group-divider">
  <%
  	int sum = 0;
  	ArrayList<Product> cartlist = (ArrayList<Product>)session.getAttribute("cartlist");
  	if(cartlist == null) cartlist=new ArrayList<Product>();
  	for(int i=0; i<cartlist.size(); i++){
  		Product product = cartlist.get(i);
  		int total = product.getUnitPrice() * product.getQuantity();
  		sum += total;
  	
  %>
    <tr>
      <th scope="row"><%=product.getPname() %></th>
      <td><%=product.getUnitPrice() %></td>
      <td><%=product.getQuantity() %></td>
      <td><%=total %></td>
      <td><a href="./removeCart.jsp?id=<%=product.getProductId() %>" class="btn btn-danger">삭제</a></td>
    </tr>
    <%
  	}
    %>
     <tr>
      <th></th>
      <th></th>
      <th>총액</th>
      <th><%=sum %></th>
      <th></th>
    </tr>
  </tbody>
</table>
<a href="./products.jsp" class="btn btn-secondary">쇼핑 계속하기</a>
	<%
		String cartId = session.getId();
	%>
<a href="./deleteCart.jsp?cartId=<%=cartId %>" class="btn btn-secondary float-end">장바구니 비우기</a>
<a href="./shippingInfo.jsp?cartId=<%=cartId %>" class="btn btn-primary float-end mx-2">주문하기</a>
    <%@ include file="footer.jsp" %>
</body>
</html>