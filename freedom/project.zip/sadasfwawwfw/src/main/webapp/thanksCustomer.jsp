<%@page import="java.net.URLDecoder"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>주문완료</title>
</head>
<body>
<%
	request.setCharacterEncoding("utf-8");	

	String Shipping_cartId = "";
	String Shipping_name = "";
	String Shipping_date = "";
	String Shipping_address = "";
	String Shipping_postId = "";

	Cookie[] cookies = request.getCookies();

	if (cookies != null) {

		for (int i = 0; i < cookies.length; i++) {

			Cookie thisCookie = cookies[i];

			String n = thisCookie.getName();

			if (n.equals("Shipping_cartId"))
		Shipping_cartId = URLDecoder.decode(thisCookie.getValue(), "utf-8");

			if (n.equals("Shipping_name"))
		Shipping_name = URLDecoder.decode(thisCookie.getValue(), "utf-8");

			if (n.equals("Shipping_date"))
		Shipping_date = URLDecoder.decode(thisCookie.getValue(), "utf-8");

			if (n.equals("Shipping_address"))
		Shipping_address = URLDecoder.decode(thisCookie.getValue(), "utf-8");

			if (n.equals("Shipping_postId"))
		Shipping_postId = URLDecoder.decode(thisCookie.getValue(), "utf-8");
		}
	}
	%>

	<h1>
		<%=Shipping_cartId%>
		<%=Shipping_name%>
		<%=Shipping_date%>
		<%=Shipping_address%>
		<%=Shipping_postId%>
	</h1>
	<%@ include file="menu.jsp" %>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
					<li class="nav-item text-success"><b>주문 완료</b></li>
				</ul>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="my-5 p-3 text-primary-emphasis bg-primary-subtle border border-primary-subtle rounded-3">
  주문해주셔서 감사합니다.
  						<p>주문은 <%=Shipping_date%>에 배송될 예정입니다.</p>
  						<p>주문번호는 <%=Shipping_cartId%>입니다.</p>
  					</div>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<p><a href="./products.jsp" class="btn btn-info">상품목록으로 이동</a></p>
				</div>
			</div>
		</div>
	</div>	
	
	<%@ include file="footer.jsp" %>
	<%
		session.invalidate();
		for(int i=0; i<cookies.length; i++){
			Cookie thisCookie = cookies[i];
			String n = thisCookie.getName();
			if (n.equals("Shipping_cartId")) thisCookie.setMaxAge(0);
			if (n.equals("Shipping_name")) thisCookie.setMaxAge(0);
			if (n.equals("Shipping_date")) thisCookie.setMaxAge(0);
			if (n.equals("Shipping_address")) thisCookie.setMaxAge(0);
			if (n.equals("Shipping_postId")) thisCookie.setMaxAge(0);
			
			response.addCookie(thisCookie);
		}
	%>
</body>
</html>










