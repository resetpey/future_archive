<%@page import="java.text.DecimalFormat"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>제품 상세 페이지</title>
<script>
	function deleteConfirm(id){
		if(confirm("해당 상품을 정말 삭제하시겠습니까?")==true)
			location.href="deleteProduct.jsp?id="+id;
		else{
			event.stopPropagation();
		}
			
	}
</script>
</head>
<body>
	<%@ include file="dbconn.jsp" %>
	<%@ include file="menu.jsp" %>
			<div class="container-fluid">
				<div class="row">
					<div class="col bg-light">
						<ul class="nav justify-content-center p-5">
					 		<li class="nav-item">
					 	    	<b>상품정보</b>
					  		</li>
						</ul>
					</div>
				</div>
			</div>
		<%
			String sql = "select * from kangs_product";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()){
		%>
			<div class="container p-5">
				<div class="row">
					<div class="col-md-6 p-5">
						<h3 class="mb-5"><%=rs.getString("p_name") %></h3>
										<img alt="" src="${pageContext.request.contextPath}/assets/img/upload/<%=rs.getString("p_fileName") %>" class="img-fluid">
						<p><%=rs.getString("p_description") %></p>
						<p><b>상품 코드 </b><%=rs.getString("p_id") %></p>
						<p><b>제조사 </b><%=rs.getString("p_manufacturer") %></p>
						<p><b>분류 </b><%=rs.getString("p_category") %></p>
												<%
							DecimalFormat formatter = new DecimalFormat("#,###");
						%>
						<p><b>재고 수 </b><%=formatter.format(rs.getInt("p_unitsInStock")) %>개</p>
						<p><b>상품 가격 </b><%=formatter.format(rs.getInt("p_unitPrice")) %>원</p>
						<p class="pl-5">
							<%
								String edit = request.getParameter("edit");
								if(edit.equals("update")){
							%>
							<a href="updateProduct.jsp?id=<%=rs.getString("p_id")%>" class="btn btn-outline-info btn-sm mt-3">정보 수정</a> 
							<% 
								}else if(edit.equals("delete")){
							%>
							<a onclick="deleteConfirm('<%=rs.getString("p_id")%>')" class="btn btn-outline-danger btn-sm mt-3">정보 삭제</a>
							<%
								}
							%>
						</p>
			<%
				}
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
			%>
					</div>
				</div>
			</div>
    <%@ include file="footer.jsp" %>
</body>
</html>