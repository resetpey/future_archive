<%@page import="java.net.URLEncoder"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>processShippingInfo</title>
</head>
<body>
	<%
		request.setCharacterEncoding("utf-8");
		Cookie cartId = new Cookie("Shipping_cartId",URLEncoder.encode(request.getParameter("cartId"), "utf-8"));
		Cookie name = new Cookie("Shipping_name",URLEncoder.encode(request.getParameter("name"), "utf-8"));
		Cookie date = new Cookie("Shipping_date",URLEncoder.encode(request.getParameter("date"), "utf-8"));
		Cookie address = new Cookie("Shipping_address",URLEncoder.encode(request.getParameter("address"), "utf-8"));
		Cookie postId = new Cookie("Shipping_postId",URLEncoder.encode(request.getParameter("postId"), "utf-8"));
		
		cartId.setMaxAge(24*60*60);
		name.setMaxAge(24*60*60);
		date.setMaxAge(24*60*60);
		address.setMaxAge(24*60*60);
		postId.setMaxAge(24*60*60);
		
		response.addCookie(cartId);
		response.addCookie(name);
		response.addCookie(date);
		response.addCookie(address);
		response.addCookie(postId);
		
		response.sendRedirect("orderConfirm.jsp");
	%>
</body>
</html>




