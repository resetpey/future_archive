package dao;

import java.util.ArrayList;

import dto.Product;


public class ProductRepository {
	private ArrayList<Product> listOfProducts = new ArrayList<Product>();
	
	private static ProductRepository instance = new ProductRepository();
	
	public static ProductRepository getInstance() {
		return instance;
	}
	
	public ProductRepository() {
		Product jacket = new Product("C1234", "파렌하이트 솔리드 슬림핏 캐주얼 자켓", 60880);
		jacket.setDescription("남성용\r\n"
				+ "/\r\n"
				+ "캐주얼 정장 재킷\r\n"
				+ "/\r\n"
				+ "무늬\r\n"
				+ ":\r\n"
				+ "무지\r\n"
				+ "/\r\n"
				+ "네크라인\r\n"
				+ ":\r\n"
				+ "테일러드(카라)\r\n"
				+ "/\r\n"
				+ "여밈방식\r\n"
				+ ":\r\n"
				+ "싱글버튼\r\n"
				+ "/\r\n"
				+ "하절기\r\n"
				+ "/\r\n"
				+ "긴소매\r\n"
				+ "/\r\n"
				+ "기장\r\n"
				+ ":\r\n"
				+ "기본\r\n"
				+ "/\r\n"
				+ "색상\r\n"
				+ ":\r\n"
				+ "블랙\r\n"
				+ ",\r\n"
				+ "블루");
		jacket.setCategory("Jacket");
		jacket.setManufacturer("ShinWon");
		jacket.setUnitsInStock(1000);
		jacket.setCondition("New");
		jacket.setFilename("C1234.png");
		
		Product jumper = new Product("C1235", "지오지아 스탠카라 윈드브레이커 점퍼", 33713);

		jumper.setDescription("바람막이점퍼\r\n"
				+ "/\r\n"
				+ "남성용\r\n"
				+ "/\r\n"
				+ "무늬\r\n"
				+ ":\r\n"
				+ "무지\r\n"
				+ "/\r\n"
				+ "긴소매\r\n"
				+ "/\r\n"
				+ "기장\r\n"
				+ ":\r\n"
				+ "기본\r\n"
				+ "/\r\n"
				+ "간절기\r\n"
				+ "/\r\n"
				+ "색상: 다크네이비, 차콜그레이");
		jumper.setCategory("Jumper");
		jumper.setManufacturer("ZIOZIA");
		jumper.setUnitsInStock(3500);
		jumper.setCondition("New");
		jumper.setFilename("C1235.png");
		
		Product suit = new Product("C1236", "지오지아 모혼방 솔리드 투버튼 수트", 99000);

		suit.setDescription("남성용\r\n"
				+ "/\r\n"
				+ "무늬\r\n"
				+ ":\r\n"
				+ "무지(솔리드)\r\n"
				+ "/\r\n"
				+ "싱글버튼\r\n"
				+ "/\r\n"
				+ "구성\r\n"
				+ ":\r\n"
				+ "자켓+바지\r\n"
				+ "/\r\n"
				+ "간절기\r\n"
				+ "/\r\n"
				+ "정장\r\n"
				+ "/\r\n"
				+ "색상: 다크네이비");
		suit.setCategory("Suit");
		suit.setManufacturer("ZIOZIA");
		suit.setUnitsInStock(25000);
		suit.setCondition("New");
		suit.setFilename("C1236.png");
		
		listOfProducts.add(jacket);
		listOfProducts.add(jumper);
		listOfProducts.add(suit);
	}
	public ArrayList<Product> getAllProducts(){
		return listOfProducts;
	}
	
	public Product getProductById(String productId) {
		Product productById = null;
		for(int i=0; i<listOfProducts.size(); i++) {
			Product product = listOfProducts.get(i);
			if(product != null && product.getProductId() != null && product.getProductId().equals(productId)) {
				productById = product;
				break;
			}
		}
		return productById;
	}
	
	public void addProduct(Product product) {
		listOfProducts.add(product);
	}
}
