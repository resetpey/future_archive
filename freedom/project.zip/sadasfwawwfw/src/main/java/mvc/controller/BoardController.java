package mvc.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.model.BoardDAO;
import mvc.model.BoardDTO;

public class BoardController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	static final int LISTCOUNT = 5;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		response.setContentType("text/html; charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		String RequestURI = request.getRequestURI();
		System.out.println("RequestURI :"+RequestURI);
		
		String contextPath = request.getContextPath();
		System.out.println("ContextPath :"+contextPath);
		
		String command = RequestURI.substring(contextPath.length());
		System.out.println("command :"+command);
		
		if(command.equals("/BoardListAction.do")) {
			//함수를 만들어서 호출하고
			requestBoardList(request);
			//어디 페이지로 이동하겠다.
			RequestDispatcher rd = request.getRequestDispatcher("./board/list.jsp");
			rd.forward(request, response);
		}
	}
	public void requestBoardList(HttpServletRequest request) {
		//게시글 목록을 불러오는 로직
		BoardDAO dao = BoardDAO.getInstance();
		List<BoardDTO> boardlist = new ArrayList<>();
		
		int pageNum = 1;
		int limit = LISTCOUNT;
		
		if(request.getParameter("pageNum") != null)
			pageNum=Integer.parseInt(request.getParameter("pageNum"));
		boardlist = dao.getBoardList(pageNum);
		request.setAttribute("boardlist", boardlist);
		request.setAttribute("pageNum", pageNum);
		
		String items = request.getParameter("items");
		String text = request.getParameter("text");
		
		int total_record = dao.getListCount(items, text);
		boardlist = dao.getBoardList(pageNum, limit, items, text);
		request.setAttribute("total_record", total_record);
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("boardlist", boardlist);
		
		int total_page;
		if(total_record % limit == 0) {
			total_page = total_record/limit;
		} else {
			total_page = total_record/limit;
			total_page = total_page + 1;
		}
	}
}
