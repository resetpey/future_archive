<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>회원 정보 수정</title>
  <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="checkout.css" rel="stylesheet" />
  <script>
    function checkForm() {
      var f = document.newMember;
      if (!f.id.value) { alert("아이디를 입력해주세요."); return false; }
      if (!f.pw.value) { alert("비밀번호를 입력해주세요."); return false; }
      if (!f.pw_confirm.value) { alert("비밀번호 확인을 입력해주세요."); return false; }
      if (f.pw.value !== f.pw_confirm.value) { alert("비밀번호를 동일하게 입력해주세요."); return false; }
      if (!f.name.value) { alert("이름을 입력해주세요."); return false; }
      f.submit();
      return true;
    }
  </script>
</head>
<body>
<%@ include file="../menu.jsp" %>

<div class="container-fluid">
  <div class="row">
    <div class="col bg-light">
      <ul class="nav justify-content-center p-5">
        <li class="nav-item text-success"><a>회원 수정</a></li>
      </ul>
    </div>
  </div>
</div>

<c:forEach var="row" items="${resultSet.rows}">
  <c:set var="mail1" value="${fn:split(row.mail, '@')[0]}" />
  <c:set var="mail2" value="${fn:split(row.mail, '@')[1]}" />
  <c:set var="year"  value="${fn:split(row.birth, '-')[0]}" />
  <c:set var="month" value="${fn:split(row.birth, '-')[1]}" />
  <c:set var="day"   value="${fn:split(row.birth, '-')[2]}" />

  <div class="container">
    <main>
      <div class="col-md-7 col-lg-8 mx-auto">
        <h4 class="mb-3">회원 정보를 기입하세요.</h4>

        <form class="needs-validation" name="newMember" action="updateMember.jsp" method="post" novalidate>
          <div class="row g-3">

            <div class="col-12">
              <label for="id" class="form-label">아이디</label>
              <input type="text" class="form-control" id="id" name="id"
                     value="<c:out value="${row.id}"/>" readonly required />
              <div class="invalid-feedback">아이디를 입력해주세요.</div>
            </div>

            <div class="col-12">
              <label for="pw" class="form-label">비밀번호</label>
              <input type="password" class="form-control" id="pw" name="pw" required />
              <div class="invalid-feedback">비밀번호를 입력해주세요.</div>
            </div>

            <div class="col-12">
              <label for="pw_confirm" class="form-label">비밀번호 확인</label>
              <input type="password" class="form-control" id="pw_confirm" name="pw_confirm" required />
              <div class="invalid-feedback">비밀번호 확인을 입력해주세요.</div>
            </div>

            <div class="col-12">
              <label for="name" class="form-label">이름 / 닉네임</label>
              <input type="text" class="form-control" id="name" name="name"
                     value="<c:out value="${row.name}"/>" required />
              <div class="invalid-feedback">이름을 입력해주세요.</div>
            </div>

            <div class="col-12">
              <label class="form-label d-block">성별</label>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="genderM" value="M"
                  <c:if test="${row.gender == 'M'}">checked</c:if> />
                <label class="form-check-label" for="genderM">남성</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="genderF" value="F"
                  <c:if test="${row.gender == 'F'}">checked</c:if> />
                <label class="form-check-label" for="genderF">여성</label>
              </div>
            </div>

            <div class="col-12">
              <label class="form-label">생년월일</label>
              <div class="row g-2">
                <div class="col-4">
                  <select class="form-select" id="birth-year" name="birthyy">
                    <option selected value="${year}">${year}</option>
                  </select>
                </div>
                <div class="col-4">
                  <select class="form-select" id="birth-month" name="birthmm">
                    <option selected value="${month}">${month}</option>
                  </select>
                </div>
                <div class="col-4">
                  <select class="form-select" id="birth-day" name="birthdd">
                    <option selected value="${day}">${day}</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="col-12">
              <label class="form-label">이메일</label>
              <div class="row g-2 align-items-center">
                <div class="col-5">
                  <input type="text" class="form-control" id="mail1" name="mail1" value="${mail1}" />
                </div>
                <div class="col-auto">@</div>
                <div class="col-5">
                  <input type="text" class="form-control" id="mail2" name="mail2" value="${mail2}" />
                </div>
              </div>
            </div>

            <div class="col-md-3">
              <label for="zip" class="form-label">우편번호</label>
              <input type="text" class="form-control" id="zip" name="zip"
                     value="<c:out value="${row.zip}"/>" />
            </div>

          </div>
        </form>
      </div>
    </main>
  </div>

  <div class="form-group my-4 text-center">
    <input type="button" class="btn btn-primary" value="수정" onclick="checkForm()" />
    <a href="deleteMember.jsp" class="btn btn-danger">탈퇴</a>
  </div>

</c:forEach>

<%@ include file="../footer.jsp" %>
<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="../checkout.js"></script>
</body>
</html>
