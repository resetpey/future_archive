<%@page import="mvc.model.BoardDTO"%>
<%@page import="java.util.List"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%@ include file="/menu.jsp" %>
		<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
			 		<li class="nav-item text-dark">
			 	    	 <b>게시판</b>
			  		</li>
				</ul>
			</div>
		</div>
	</div>
	<div class=container>
	<form action='<c:url value="/BoardlistAction.do"/>' method="post">
		<div class="row">
			<div class="col">
			<%
				// String sessionId = (String)session.getAttribute("sessionId");
				int pageNum = (Integer)request.getAttribute("pageNum");
				int total_record = (Integer)request.getAttribute("total_record");
				int total_page = (Integer)request.getAttribute("total_page");
			%>
				<div class="text-start">
					<select name="items">
							<option value="subject">제목에서</option>
							<option value="content">본문에서</option>
							<option value="name">글쓴이에서</option>
					</select>
					<input type="text" name="text"/>
					<input type="submit" value="검색" class="btn btn-info"/>
					
					<a href="" class="btn btn-warning">검색 초기화</a>
				</div>
				<div class="text-right">
					<span class="badge badge-success">전체 <%=total_record %>건</span>
				</div>
				<table class="table">
					<tr>
						<th>번호</th>
						<th>제목</th>
						<th>작성일</th>
						<th>수정일</th>
						<th>조회</th>
						<th>글쓴이</th>
					</tr>
					<%
						List boardlist = (List)request.getAttribute("boardlist");
						for(int i=0; i<boardlist.size(); i++){
							BoardDTO boardDTO = (BoardDTO)boardlist.get(i);
					%>
					<tr>
						<td><%=boardDTO.getNum() %></td>
						<td><a href="./BoardViewAction.do?num=<%=boardDTO.getNum() %>&pageNum=<%=pageNum %>"><%=boardDTO.getSubject() %></a></td>
						<td><%=boardDTO.getRegist_day() %></td>
						<td><%=boardDTO.getUpdate_day() %></td>
						<td><%=boardDTO.getHit() %></td>
						<td><%=boardDTO.getName() %></td>
					</tr>
					<%
						}
					%>
				</table>
				<div>
					<a href="#" onclick="checkForm();" class="btn btn-warning">글쓰기</a>
				</div>
			</div>
		</div>
		<div class="text-center">
			<c:set value="<%=pageNum %>" var="pageNum"/>
			<c:forEach var="i" begin="1" end=<%=total_page %>>
				<a href="<c:url value='/boardListAction.do?pageNum=${i}'/>">
					<c:choose>
						<c:when test="${pageNum==i }"><b>[${i }]</b></c:when>
						<c:otherwise>[${i }]</c:otherwise>
					</c:choose>
				</a>
				
			</c:forEach>
		</div>
	</form>
	</div>
	
    <%@ include file="/footer.jsp" %>
</body>
</html>