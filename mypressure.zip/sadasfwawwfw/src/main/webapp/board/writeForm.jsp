<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<script>
	function checForm(){
		
		if(!document.)
	}
</script>
</head>
<body>
	<%@ include file="/menu.jsp" %>
	<%
		String name = (String)request.getAttribute("name");
	%>
		<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
			 		<li class="nav-item text-dark">
			 	    	 <b>게시판</b>
			  		</li>
				</ul>
			</div>
		</div>
	</div>
	<form name="newWrite" action="./BoardWriteForm.do" method="post">
		<div class="form-group my-4">
			<label for="id">아이디</label>
			<input type="text" class="form-control" id="id" name="id" placeholder="아이디" required autofocus> 
		</div>
		<div class="form-group">
			<label for="name">이름</label>
			<input type="text" class="form-control" id="name" name="name" value="<%=name %>" readonly> 
		</div>
		<div class="form-group my-3">
			<label for="subject">제목</label>
			<input type="text" class="form-control" id="subject" name="subject" placeholder="제목" required autofocus> 
		</div>
		<div class="form-group my-3">
			<label for="content">내용</label>
			<textarea class="form-control" id="content" name="content" placeholder="내용을 입력해주세요" rows="15"></textarea> 
		</div>
		<div class="form-group my-4">
			<input type="submit" class="btn btn-primary" value="등록"> 
			<input type="reset" class="btn btn-primary" value="등록"> 
		</div>
	</form>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    <%@ include file="footer.jsp" %>
	
</body>
</html>