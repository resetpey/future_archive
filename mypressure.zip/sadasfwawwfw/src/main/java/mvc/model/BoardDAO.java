package mvc.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import mvc.database.DBConnection;

public class BoardDAO {
    private static BoardDAO instance;

    private BoardDAO() {}

    public static BoardDAO getInstance() {
        if (instance == null) instance = new BoardDAO();
        return instance;
    }

    public ArrayList<BoardDTO> getBoardList(int page) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String sql = "select * from kangs_board order by num desc";
        ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();

        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                BoardDTO board = new BoardDTO();
                board.setNum(rs.getInt("num"));
                board.setId(rs.getString("id"));
                board.setName(rs.getString("name"));
                board.setSubject(rs.getString("subject"));
                board.setContent(rs.getString("content"));
                board.setHit(rs.getInt("hit"));
                board.setIp(rs.getString("ip"));
                board.setRegist_day(rs.getString("regist_day"));
                board.setUpdate_day(rs.getString("update_day"));
                list.add(board);
            }
        } catch (Exception e) {
            System.out.println("getBoardList()의 에러 " + e);
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    public int getListCount(String items, String text) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        int x = 0;
        String sql;

        boolean hasSearch = (items != null && text != null && !items.isEmpty() && !text.isEmpty());

        if (!hasSearch) {
            sql = "select count(*) from kangs_board";
        } else {
            sql = "select count(*) from kangs_board where " + items + " like ?";
        }

        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            if (hasSearch) {
                pstmt.setString(1, "%" + text + "%");
            }
            rs = pstmt.executeQuery();

            if (rs.next()) x = rs.getInt(1);
        } catch (Exception e) {
            System.out.println("getListCount()의 에러 : " + e);
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return x;
    }

    public ArrayList<BoardDTO> getBoardList(int page, int limit, String items, String text) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        int total_record = getListCount(items, text);
        int start = (page - 1) * limit;
        int index = start + 1;

        boolean hasSearch = (items != null && text != null && !items.isEmpty() && !text.isEmpty());

        String sql;
        if (!hasSearch) {
            sql = "select * from kangs_board order by num desc";
        } else {
            sql = "select * from kangs_board where " + items + " like ? order by num desc";
        }

        ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();

        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            if (hasSearch) {
                pstmt.setString(1, "%" + text + "%");
            }
            rs = pstmt.executeQuery();

            while (index <= (start + limit) && index <= total_record && rs.absolute(index)) {
                BoardDTO board = new BoardDTO();
                board.setNum(rs.getInt("num"));
                board.setId(rs.getString("id"));
                board.setName(rs.getString("name"));
                board.setSubject(rs.getString("subject"));
                board.setContent(rs.getString("content"));
                board.setHit(rs.getInt("hit"));
                board.setIp(rs.getString("ip"));
                board.setRegist_day(rs.getString("regist_day"));
                board.setUpdate_day(rs.getString("update_day"));
                list.add(board);

                index++;
            }
        } catch (Exception e) {
            System.out.println("getBoardList()의 에러 : " + e);
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }
    public String getLoginNameById(String id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String name = null;
        String sql="select * from kangs_member where id=?";
        
        try {
            conn = DBConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            
            if(rs.next()) name = rs.getString("name");
        }catch(Exception e) {
        	System.out.println("getLoginNameById()에러 : "+e);
        }finally {
        	try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
        	}catch(SQLException e) {
        		e.printStackTrace();
        	}
        }
        return name;
    }
    
    public void insertBoard(BoardDTO board) {
    	Connection conn = null;
    	PreparedStatement pstmt = null;
    	
    	try {
    		conn = DBConnection.getConnection();
    		String sql="insert into kangs_board values(kimssam_num.nextval,?,?,?,?,?,?, sysdate, sysdate)";
    		pstmt = conn.prepareStatement(sql);
    		pstmt.setString(1, board.getId());
    		pstmt.setString(2, board.getName());
    		pstmt.setString(3, board.getSubject());
    		pstmt.setString(4, board.getContent());
    		pstmt.setInt(5, board.getHit());
    		pstmt.setString(6, board.getIp());
    		
    		pstmt.executeUpdate();
    	}catch(Exception e) {
    		System.out.println("insertBoard()에러 : "+e);
    	}finally {
    		try {
    			if(pstmt != null) pstmt.close();
    			if(conn != null) conn.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    }	
    public BoardDTO getBoardByNum(int num) {
    	
    }
   
    public void updateHit(int num) {
    	Connection conn = null;
    	PreparedStatement pstmt = null;
    	ResultSet rs = null;
    	
    	try {
    		conn = DBConnection.getConnection();
    		String sql = "update kangs_board set hit = hit+1 where num=?";
    		pstmt = conn.prepareStatement(sql);
    		pstmt.setInt(1,  num);
    		pstmt.executeQuery();
    	}catch(Exception e) {
    		System.out.println("updateHit()에러 : "+e);
    	}finally {
    		try {
    			if(rs != null) rs.close();
    			if(pstmt != null) pstmt.close();
    			if(conn != null) conn.close();
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}
    	}
    }
}