package mvc.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import mvc.model.BoardDAO;

public class BoardController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	static final int LISTCOUNT = 5;

	@Override
	protected void doGet(HttpServletRequest request, HttpServeltResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	protected void doPoet(HttpServletRequest request, HttpServeltResponse response) throws UnsupportedEncodingException {
		response.setContentType("text/html; charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		String RequestURI = request.getRequestURI();
		System.out.println("RequestURI :"+RequestURI);
		
		String contextPath = request.getContextPath();
		System.out.println("ContextPath :"+contextPath);
		
		String command = RequestURI.substring(contextPath.length());
		System.out.println("command :"+command);
		
		if(command.equals("/BoardListAction.do")) {
			//함수를 만들어서 호출하고
			requestBoardList(request);
			//어디 페이지로 이동하겠다.
			RequestDispatcher rd = request.getRequestDispatcher("./board/list.jsp");
			rd.forward(request, response);
		}
	}
	public void requestBoardList(HttpServletRequest request) {
		//게시글 목록을 불러오는 로직
		BoardDAO dao = BoardDAO.getInstance();
		List<BoardDTO> boardlist = new ArrayList<>();
		
		int pageNum = 1;
		int limit = LISTCOUNT;
		
		if(request.getParameter("pageNum") != null)
			pageNum=Integer.parseInt(request.getParameter("pageNum"));
		boardlist = dao.getBoardList(pageNum);
		request.setAttribute("boardlist", boardlist);
	}
}
