<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%@ include file="menu.jsp" %>
	<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
					<li class="nav-item text-success"><a>로그인</a></li>
				</ul>
			</div>
		</div>
	</div>

	<form action="j_security_check" method="post">
	<div class="container p-5">
		<div class="row align-items0center p-2">
			<div class="col-6 col-offset-3">
				<%
					String error = request.getParameter("error");
					if(error != null){
						out.println("<div class='alert alert-danger d-flex align-items-center' role='alert'>  An example danger alert with an icon</div>");
					}
				%>
			</div>
		</div>
		<div class="row g-3 align-items-center">
		<div class="col-auto">
		  <label for="inputPassword6" class="col-form-label">ID</label>
		</div>
		<div class="col-auto">
		  <input type="text" id="inputId" class="form-control" aria-describedby="id" name="j_username">
		</div>
		<div class="col-auto">
		  <span id="passwordHelpInline" class="form-text">
		    Must be 2-20 characters long.
		  </span>
		</div>
		</div>
		<div class="row g-3 align-items-center">
		<div class="col-auto">
		  <label for="inputPassword6" class="col-form-label">PW</label>
		</div>
		<div class="col-auto">
		  <input type="password" id="inputPassword6" class="form-control" aria-describedby="passwordHelpInline" name="j_password">
		</div>
		<div class="col-auto">
		  <span id="passwordHelpInline" class="form-text">
		    Must be 8-20 characters long.
		  </span>
		</div>
		</div>
		<div class="col-12">
		  <button type="submit" class="btn btn-primary">Sign in</button>
		</div>
	</div>
	</form>
	
    <%@ include file="footer.jsp" %>
</body>
</html>