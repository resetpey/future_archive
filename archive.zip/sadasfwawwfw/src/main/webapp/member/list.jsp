<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<%@ include file="/menu.jsp" %>
		<div class="container-fluid">
		<div class="row">
			<div class="col bg-light">
				<ul class="nav justify-content-center p-5">
			 		<li class="nav-item text-dark">
			 	    	 <b>게시판</b>
			  		</li>
				</ul>
			</div>
		</div>
	</div>
	<div class=container>
		<div class="row">
			<div class="col">
				<table class="table">
					<tr>
						<th>번호</th>
						<th>제목</th>
						<th>작성일</th>
						<th>수정일</th>
						<th>조회</th>
						<th>글쓴이</th>
					</tr>
					<%
						List boardlist = request.getAttribute("boardlist");
						for(int i=0; i<boardlist.size(); i++){
							BoardDTO boardDTO = (BoardDTO)boardlist.get(i);
						}
					%>
					<tr>
						<td><%=boardDTO.getNum() %></td>
						<td><%=boardDTO.getSubject() %></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
				</table>
			</div>
		</div>
	</div>
    <%@ include file="/footer.jsp" %>
</body>
</html>